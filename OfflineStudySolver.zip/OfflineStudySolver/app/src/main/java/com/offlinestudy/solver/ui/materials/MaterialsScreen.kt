package com.offlinestudy.solver.ui.materials

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.offlinestudy.solver.UiState
import com.offlinestudy.solver.database.DocumentEntity
import java.text.SimpleDateFormat
import java.util.*

/** Sections 5 & 19: import + manage study materials via the Storage Access Framework. */
@Composable
fun MaterialsScreen(
    state: UiState,
    onImport: (Uri, String, String?) -> Unit,
    onReindex: (DocumentEntity) -> Unit,
    onDelete: (DocumentEntity) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val name = queryFileName(context, uri) ?: uri.lastPathSegment ?: "document"
            val mime = context.contentResolver.getType(uri)
            onImport(uri, name, mime)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(title = { Text("My Materials") }, navigationIcon = {
            TextButton(onClick = onBack) { Text("Back") }
        })

        Button(
            onClick = {
                picker.launch(arrayOf(
                    "application/pdf",
                    "text/plain",
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                ))
            },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) { Text("+ Add Materials") }

        LazyColumn {
            items(state.documents, key = { it.id }) { doc ->
                MaterialCard(doc, onReindex = { onReindex(doc) }, onDelete = { onDelete(doc) })
            }
        }
    }
}

@Composable
private fun MaterialCard(doc: DocumentEntity, onReindex: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(doc.fileName, style = MaterialTheme.typography.titleMedium)
            Text("${formatSize(doc.sizeBytes)} • ${doc.pageCount} pages • ${doc.chunkCount} chunks")
            Text("Status: ${doc.indexingStatus} • Added ${formatDate(doc.dateAddedEpochMs)}")
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onReindex) { Text("Re-index") }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

private fun formatSize(bytes: Long): String {
    val kb = bytes / 1024.0
    return if (kb < 1024) "%.0f KB".format(kb) else "%.1f MB".format(kb / 1024.0)
}

private fun formatDate(epochMs: Long): String =
    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(epochMs))

private fun queryFileName(context: android.content.Context, uri: Uri): String? {
    val cursor = context.contentResolver.query(uri, null, null, null, null)
    cursor?.use {
        val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
        if (it.moveToFirst() && nameIndex >= 0) return it.getString(nameIndex)
    }
    return null
}
