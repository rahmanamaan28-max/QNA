package com.offlinestudy.solver.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlinestudy.solver.UiState
import com.offlinestudy.solver.llm.ModelStatus

/** Section 14: home screen with the status summary and main action buttons. */
@Composable
fun HomeScreen(
    state: UiState,
    onAskFromPhoto: () -> Unit,
    onAskTyped: () -> Unit,
    onMyMaterials: () -> Unit,
    onSettings: () -> Unit,
    onSearch: () -> Unit = {}
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(Modifier.height(24.dp))
        Text("OFFLINE STUDY SOLVER", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(24.dp))

        Button(onClick = onAskFromPhoto, modifier = Modifier.fillMaxWidth()) { Text("📷 Ask from Photo") }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onAskTyped, modifier = Modifier.fillMaxWidth()) { Text("✍ Ask Question") }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onMyMaterials, modifier = Modifier.fillMaxWidth()) { Text("📚 My Materials") }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onSearch, modifier = Modifier.fillMaxWidth()) { Text("🔎 Search Materials") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("⚙ Settings") }

        Spacer(Modifier.height(32.dp))
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                val llmInstalled = state.modelState?.llmStatus == ModelStatus.INSTALLED
                val embedInstalled = state.modelState?.embeddingStatus == ModelStatus.INSTALLED
                StatusRow("AI Model", if (llmInstalled) "Installed" else "Not installed")
                StatusRow("OCR", "Installed") // bundled in APK
                StatusRow("Embedding model", if (embedInstalled) "Installed" else "Not installed")
                StatusRow("Materials", "${state.documents.size} documents")
                StatusRow("Indexed chunks", "${state.chunkCount}")
                StatusRow("Internet", "Not required")
            }
        }
    }
}

@Composable
private fun StatusRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
