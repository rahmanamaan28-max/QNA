package com.offlinestudy.solver.ui.question

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlinestudy.solver.UiState
import com.offlinestudy.solver.llm.AnswerMode

/**
 * Sections 7, 8, 15: shows OCR'd (or typed) question(s), lets the user edit
 * text, pick an answer mode, and choose "Answer All" or one question at a
 * time when multiple questions were detected in one photo.
 */
@Composable
fun QuestionScreen(
    state: UiState,
    onModeSelected: (AnswerMode) -> Unit,
    onAskQuestion: (String) -> Unit,
    onBack: () -> Unit
) {
    var typedQuestion by remember { mutableStateOf("") }
    var editableQuestions by remember(state.recognizedQuestions) {
        mutableStateOf(state.recognizedQuestions.toMutableList())
    }
    var modeMenuExpanded by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(title = { Text("Ask a Question") }, navigationIcon = {
            TextButton(onClick = onBack) { Text("Back") }
        })

        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { modeMenuExpanded = true }) { Text("Answer Mode: ${state.answerMode.label} ▼") }
            DropdownMenu(expanded = modeMenuExpanded, onDismissRequest = { modeMenuExpanded = false }) {
                AnswerMode.entries.forEach { mode ->
                    DropdownMenuItem(text = { Text(mode.label) }, onClick = {
                        onModeSelected(mode); modeMenuExpanded = false
                    })
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        if (editableQuestions.isEmpty()) {
            Text("Type your question:", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = typedQuestion,
                onValueChange = { typedQuestion = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                label = { Text("Question") }
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onAskQuestion(typedQuestion) }, enabled = typedQuestion.isNotBlank()) {
                Text("FIND ANSWER")
            }
        } else {
            Text("Recognized Question${if (editableQuestions.size > 1) "s" else ""}:", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(editableQuestions.size) { index ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Question ${index + 1}", style = MaterialTheme.typography.labelMedium)
                            OutlinedTextField(
                                value = editableQuestions[index],
                                onValueChange = { newText ->
                                    editableQuestions = editableQuestions.toMutableList().also { it[index] = newText }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(6.dp))
                            Button(onClick = { onAskQuestion(editableQuestions[index]) }) { Text("FIND ANSWER") }
                        }
                    }
                }
            }
            if (editableQuestions.size > 1) {
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { onAskQuestion(editableQuestions.joinToString("\n") { "- $it" }) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ANSWER ALL") }
            }
        }
    }
}
