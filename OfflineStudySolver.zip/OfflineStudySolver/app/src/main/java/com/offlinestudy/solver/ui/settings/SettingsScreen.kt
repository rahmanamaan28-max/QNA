package com.offlinestudy.solver.ui.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlinestudy.solver.UiState
import com.offlinestudy.solver.llm.ModelStatus

/** Sections 14/20/21: Model Manager -- shows install status, lets the user copy in a GGUF model file. */
@Composable
fun SettingsScreen(state: UiState, onInstallModel: (Uri) -> Unit, onBack: () -> Unit) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let(onInstallModel)
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(title = { Text("Settings / Model Manager") }, navigationIcon = {
            TextButton(onClick = onBack) { Text("Back") }
        })

        Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("OCR Model", style = MaterialTheme.typography.titleMedium)
                Text("Status: Installed (bundled in app)")
            }
        }

        Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Embedding Model", style = MaterialTheme.typography.titleMedium)
                val installed = state.modelState?.embeddingStatus == ModelStatus.INSTALLED
                Text("Status: ${if (installed) "Installed" else "Not installed"}")
                if (!installed) {
                    Text(
                        "Place embedding.tflite and vocab.txt under assets/models/ at build time. See README.",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Local LLM", style = MaterialTheme.typography.titleMedium)
                val installed = state.modelState?.llmStatus == ModelStatus.INSTALLED
                Text("Status: ${if (installed) "Installed" else "Not installed"}")
                if (installed) {
                    Text(state.modelState?.llmModelPath ?: "", style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { picker.launch("*/*") }) { Text("Import .gguf model file") }
                Text(
                    "This copies a model file already on your device into app storage. " +
                        "It never downloads anything.",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        if (state.errorMessage != null) {
            Spacer(Modifier.height(8.dp))
            Text(state.errorMessage, color = MaterialTheme.colorScheme.error)
        }
    }
}
