package com.offlinestudy.solver.ui.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.offlinestudy.solver.database.ChunkEntity
import com.offlinestudy.solver.retrieval.HybridRetriever
import kotlinx.coroutines.launch

/** Section 18: keyword/semantic search across the local library, independent of Q&A. */
@Composable
fun SearchMaterialsScreen(retriever: HybridRetriever, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ChunkEntity>>(emptyList()) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(title = { Text("Search Materials") }, navigationIcon = {
            TextButton(onClick = onBack) { Text("Back") }
        })
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search your uploaded books") },
            trailingIcon = {
                TextButton(onClick = {
                    scope.launch { results = retriever.retrieve(query, topK = 20).chunks.map { it.chunk } }
                }) { Text("Go") }
            }
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(results, key = { it.id }) { chunk ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(chunk.documentName, style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (chunk.pageNumber > 0) "Page ${chunk.pageNumber}" else "Page information unavailable",
                            style = MaterialTheme.typography.labelSmall
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(chunk.chunkText.take(220) + if (chunk.chunkText.length > 220) "..." else "")
                    }
                }
            }
        }
    }
}
