package com.offlinestudy.solver.ui.answer

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.offlinestudy.solver.UiState
import com.offlinestudy.solver.retrieval.EvidenceConfidence

/** Section 16: answer display with sources, copy/save/follow-up actions. */
@Composable
fun AnswerScreen(state: UiState, onFollowUp: (String) -> Unit, onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var followUpText by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TopAppBar(title = { Text("Answer") }, navigationIcon = {
            TextButton(onClick = onBack) { Text("Back") }
        })

        if (state.isAnswering) {
            Spacer(Modifier.height(24.dp))
            CircularProgressIndicator()
            Text("Thinking locally...", Modifier.padding(top = 8.dp))
            return@Column
        }

        val answer = state.currentAnswer ?: run {
            Text("No answer yet."); return@Column
        }

        Text("QUESTION", style = MaterialTheme.typography.labelLarge)
        Text(answer.question, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))

        Text("ANSWER", style = MaterialTheme.typography.labelLarge)
        Text(answer.answerText, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        ConfidenceBadge(answer.confidence)
        Spacer(Modifier.height(16.dp))

        if (!answer.notFound) {
            Text(if (answer.sources.size > 1) "SOURCES" else "SOURCE", style = MaterialTheme.typography.labelLarge)
            answer.sources.forEach { src ->
                val pageLabel = src.pageNumber?.let { "Page $it" } ?: "Page information unavailable"
                Text("• ${src.documentName} — $pageLabel${src.section?.let { " ($it)" } ?: ""}")
            }
            Spacer(Modifier.height(16.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(answer.answerText)) }) { Text("COPY") }
            OutlinedButton(onClick = { /* Persist to a "Saved Answers" table -- straightforward Room addition */ }) { Text("SAVE") }
        }

        Spacer(Modifier.height(16.dp))
        Text("ASK FOLLOW-UP", style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = followUpText,
            onValueChange = { followUpText = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("e.g. Explain it in simpler words") }
        )
        Button(onClick = { onFollowUp(followUpText); followUpText = "" }, enabled = followUpText.isNotBlank()) {
            Text("Ask")
        }
    }
}

@Composable
private fun ConfidenceBadge(confidence: EvidenceConfidence) {
    val (label, color) = when (confidence) {
        EvidenceConfidence.STRONG -> "Evidence: Strong match" to MaterialTheme.colorScheme.primary
        EvidenceConfidence.MODERATE -> "Evidence: Moderate match" to MaterialTheme.colorScheme.tertiary
        EvidenceConfidence.WEAK -> "Evidence: Weak match" to MaterialTheme.colorScheme.error
        EvidenceConfidence.NONE -> "Evidence: Not found" to MaterialTheme.colorScheme.error
    }
    AssistChip(onClick = {}, label = { Text(label) }, colors = AssistChipDefaults.assistChipColors(labelColor = color))
    Text(
        "This reflects retrieval match quality, not a calibrated probability of correctness.",
        style = MaterialTheme.typography.labelSmall
    )
}
